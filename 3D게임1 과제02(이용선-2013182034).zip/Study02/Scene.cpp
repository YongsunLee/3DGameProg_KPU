#include "stdafx.h"
#include "Scene.h"
#include "Player.h"

CScene::CScene()
{
	m_pd3dGraphicsRootSignature = NULL;
	
}

CScene::~CScene()
{
}

bool CScene::OnProcessingMouseMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam)
{
	return false;
}

bool CScene::OnProcessingKeyboardMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam)
{
	return false;
}

void CScene::BuildObjects(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList) {
	m_pd3dGraphicsRootSignature = CreateGraphicsRootSignature(pd3dDevice);
	m_nShaders = 2;
	m_pShaders = new CInstancingShader[m_nShaders];

	// ���׸���
	m_pShaders[0].CreateShader(pd3dDevice, m_pd3dGraphicsRootSignature);

	m_nWall = 20;
	m_pWall = new CGameObject*[m_nWall];

	CWallMeshDiffused *pWallMesh = new CWallMeshDiffused(pd3dDevice, pd3dCommandList, 100.0f, 100.0f, 20.0f);
	for (int i = 0; i < m_nWall; ++i) {
		CWallObject *wall = new CWallObject();
		wall->SetPosition(0.0f, 0.0f, 0.0f + (i * 20));
		wall->SetMesh(pWallMesh);
		wall->wallCnt();
		wall->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
			XMFLOAT3(15.0f, 15.0f, 10.0f),
			XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
		wall->SetPlanes();
		m_pWall[i] = wall;
		m_pWall[i]->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
			XMFLOAT3(50.0f, 50.0f, 10.0f),
			XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	}

	// ���� ������
	m_pxmf4WallPlanes[0] = XMFLOAT4(+1.0f, 0.0f, 0.0f, 0.0f);
	m_pxmf4WallPlanes[1] = XMFLOAT4(-1.0f, 0.0f, 0.0f, 0.0f);
	m_pxmf4WallPlanes[2] = XMFLOAT4(0.0f, +1.0f, 0.0f, 0.0f);
	m_pxmf4WallPlanes[3] = XMFLOAT4(0.0f, -1.0f, 0.0f, 0.0f);
	m_pxmf4WallPlanes[4] = XMFLOAT4(0.0f, 0.0f, +1.0f, 10.0f);
	m_pxmf4WallPlanes[5] = XMFLOAT4(0.0f, 0.0f, -1.0f, 10.0f);
	
	m_pShaders[0].BuildObjects(pd3dDevice, pd3dCommandList, m_pWall, m_nWall);

	// ť�� 1�� ���̴�
	m_pShaders[1].CreateShader(pd3dDevice, m_pd3dGraphicsRootSignature);

	m_nCube = 10;
	m_pCube = new CGameObject*[m_nCube];

	default_random_engine dre;
	uniform_int_distribution<> dir_ui(0, 1);
	uniform_int_distribution<> crossDir_ui(0, 5);
	uniform_int_distribution<> type_ui(0, 2);
	uniform_real_distribution<> pos_ur(-12.0, 12.0);
	uniform_real_distribution<> spd_ur(0.05f, 0.15f);
	dre.seed(chrono::system_clock::now().time_since_epoch().count());

	CCubeMeshDiffused *pCubeMesh = new CCubeMeshDiffused(pd3dDevice, pd3dCommandList, 8.f, 8.f, 8.f);
	for (int i = 0; i < m_nCube; ++i) {
		CRotatingObject *cube = new CRotatingObject();

		CubeType objectsType = (CubeType)type_ui(dre);
		//CubeType objectsType = (CubeType)1;
		float xPos = pos_ur(dre);
		float yPos = pos_ur(dre);
		int dir = dir_ui(dre);
		float speed = spd_ur(dre);

		switch (objectsType)
		{
		case CubeType::XPOS:
			cube->SetObjectType(objectsType);
			cube->SetPosition(xPos, yPos, 10.0f + (i * 10.0f));
			cube->SetMesh(pCubeMesh);
			if (dir == 0) { cube->SetMovingSpeed(speed);
							cube->SetRotationAxis(XMFLOAT3(1.0f, 0.0f, 0.0f));
							cube->SetMovingDirection(XMFLOAT3(1.0f, 0.0f, 0.0f));
			}
			else { cube->SetMovingSpeed(speed * -1.0f);
				   cube->SetRotationAxis(XMFLOAT3(-1.0f, 0.0f, 0.0f)); 
				   cube->SetMovingDirection(XMFLOAT3(-1.0f, 0.0f, 0.0f));}
			cube->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
						  XMFLOAT3(4.0f, 4.0f, 4.0f),
						  XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			m_pCube[i] = cube;
			break;
		case CubeType::YPOS:
			cube->SetObjectType(objectsType);
			cube->SetPosition(xPos, yPos, 10.0f + (i * 10.0f));
			cube->SetMesh(pCubeMesh);
			if (dir == 0) {
				cube->SetMovingSpeed(speed);
				cube->SetRotationAxis(XMFLOAT3(0.0f, 1.0f, 0.0f));
				cube->SetMovingDirection(XMFLOAT3(0.0f, 1.0f, 0.0f));}
			else {
				cube->SetMovingSpeed(speed * -1.0f);
				cube->SetRotationAxis(XMFLOAT3(0.0f, -1.0f, 0.0f));
				cube->SetMovingDirection(XMFLOAT3(0.0f, -1.0f, 0.0f));
			}
			cube->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
				XMFLOAT3(4.0f, 4.0f, 4.0f),
				XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			m_pCube[i] = cube;
			break;
		case CubeType::ZPOS:
			cube->SetObjectType(objectsType);
			cube->SetPosition(xPos, yPos, 10.0f + (i * 10.0f));
			cube->SetMesh(pCubeMesh);
			if (dir == 0) {
				cube->SetMovingSpeed(speed);
				cube->SetRotationAxis(XMFLOAT3(0.0f, 0.0f, 1.0f));
				cube->SetMovingDirection(XMFLOAT3(0.0f, 0.0f, 1.0f));
			}
			else {
				cube->SetMovingSpeed(speed * -1.0f);
				cube->SetRotationAxis(XMFLOAT3(0.0f, 0.0f, -1.0f));
				cube->SetMovingDirection(XMFLOAT3(0.0f, 0.0f, -1.0f));
			}
			cube->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
				XMFLOAT3(4.0f, 4.0f, 4.0f),
				XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			m_pCube[i] = cube;
			break;
		//case CubeType::CROSSPOS:
			//break;
		}
	}

	m_pShaders[1].BuildObjects(pd3dDevice, pd3dCommandList, m_pCube, m_nCube);
}

void CScene::ReleaseObjects() {
	if (m_pd3dGraphicsRootSignature)
		m_pd3dGraphicsRootSignature->Release();
	for (int i = 0; i < m_nShaders; i++) {
		m_pShaders[i].ReleaseShaderVariables();
		m_pShaders[i].ReleaseObjects();
	}
	if (m_pShaders) delete[] m_pShaders;
}

bool CScene::ProcessInput(UCHAR * pKeysBuffer)
{
	return false;
}

void CScene::AnimateObjects(float fTimeElapsed)
{
	for (int i = 0; i < m_nWall; ++i) m_pWall[i]->GetPlayerPosition(player->GetPosition());
	for (int i = 0; i < m_nShaders; i++) {
		m_pShaders[i].AnimateObjects(fTimeElapsed);
	}

	// ť�� - ��
	/*
	*/
	for (int i = 0; i < m_nCube; i++)
	{
		ContainmentType containType;
		for (int k = 0; k < m_nWall; ++k) {
			containType = m_pWall[k]->m_xmOOBB.Contains(m_pCube[i]->m_xmOOBB);
			if (containType != NULL) break;
		}
		
		switch (containType)
		{
			// �ܺ�
		case DISJOINT:
		{
			int nPlaneIndex = -1;
			for (int j = 0; j < 4; j++)
			{
				PlaneIntersectionType intersectType = m_pCube[i]->m_xmOOBB.Intersects(XMLoadFloat4(&m_pxmf4WallPlanes[j]));
				if (intersectType == BACK)
				{
					nPlaneIndex = j;
					break;
				}
			}
			if (nPlaneIndex != -1)
			{
				XMVECTOR xmvNormal = XMVectorSet(m_pxmf4WallPlanes[nPlaneIndex].x, m_pxmf4WallPlanes[nPlaneIndex].y, m_pxmf4WallPlanes[nPlaneIndex].z, 0.0f);
				XMVECTOR xmvReflect = XMVector3Reflect(XMLoadFloat3(&m_pCube[i]->m_xmf3MovingDirection), xmvNormal);
				XMStoreFloat3(&m_pCube[i]->m_xmf3MovingDirection, xmvReflect);
			}
			break;
		}
		// �浹
		case INTERSECTS:
		{
			int nPlaneIndex = -1;
			// �յ� �浹 ����.. �������� j < 6
			for (int j = 0; j < 4; j++)
			{
				PlaneIntersectionType intersectType = m_pCube[i]->m_xmOOBB.Intersects(XMLoadFloat4(&m_pxmf4WallPlanes[j]));
				if (intersectType == INTERSECTING)
				{
					nPlaneIndex = j;
					break;
				}
			}
			if (nPlaneIndex != -1)
			{
				XMVECTOR xmvNormal = XMVectorSet(m_pxmf4WallPlanes[nPlaneIndex].x, m_pxmf4WallPlanes[nPlaneIndex].y, m_pxmf4WallPlanes[nPlaneIndex].z, 0.0f);
				XMVECTOR xmvReflect = XMVector3Reflect(XMLoadFloat3(&m_pCube[i]->m_xmf3MovingDirection), xmvNormal);
				XMStoreFloat3(&m_pCube[i]->m_xmf3MovingDirection, xmvReflect);
			}
			break;
		}
		// ����
		case CONTAINS:
			break;
		}
	}

	// ť�� �����
	for (int cubeCnt = 0; cubeCnt < m_nCube; ++cubeCnt) {
		XMFLOAT3 CubePos = m_pCube[cubeCnt]->GetPosition();
		if (player->GetPosition().z >(CubePos.z + 20.0f)) {
			default_random_engine dre;
			uniform_real_distribution<> pos_ur(-30.0, 30.0);
			float xPos = pos_ur(dre);
			float yPos = pos_ur(dre);
			m_pCube[cubeCnt]->SetCubeType(player, m_pCube, cubeCnt);
			m_pCube[cubeCnt]->SetPosition(xPos, yPos, player->GetPosition().z + 80.0f);
		}
	}

	// �� - �÷��̾�
	/*
	for (int i = 0; i < m_nWall; ++i) {
		// � ���ȿ� �÷��̾ �ִ°�?
		if (m_pWall[i]->m_xmOOBB.Contains(player->m_xmOOBB)) {
			// � ���̶� �浹?
			for (int j = 0; j < 4; ++j) {
				if (player->m_xmOOBB.Intersects(XMLoadFloat4(&m_pxmf4WallPlanes[j]))) {
					// �浹�� ���� ���� ���͸� �޾Ƽ� �ݴ�� �ӵ��� ���� ������ �о������.
					cout << "�浹 " << endl;
					switch (j)
					{
					case 0:
						player->MoveStrafe(10.0f);
						break;
					case 1:
						player->MoveStrafe(-10.0f);
						break;
					case 2:
						player->MoveUp(10.0f);
						break;
					case 3:
						player->MoveUp(-10.0f);
						break;
					}
				}
			}
		}
	}
	*/

	// �÷��̾� - ť�� �浹 üũ
	for (int i = 0; i < m_nCube; ++i) {
		if (m_pCube[i]->m_xmOOBB.Intersects(player->m_xmOOBB))
		{
			m_pCube[i]->m_pCollider = player;
			player->m_pCollider = m_pCube[i];
		}
	}

	for (int i = 0; i < m_nCube; i++)
	{
		//
		if (m_pCube[i]->m_pCollider && player->m_pCollider)
		{
			// �÷��̾� ��ġ �ʱ�ȭ
			player->SetPosition(XMFLOAT3(0.0f, 0.0f, -50.0f));
			// �� �ʱ�ȭ
			for (int wallCnt = 0; wallCnt < m_nWall; ++wallCnt) {
				m_pWall[wallCnt]->SetPosition(0.0f, 0.0f, 0.0f + (wallCnt * 20));
			}
			// ť�� �ʱ�ȭ
			for (int cubeCnt = 0; cubeCnt < m_nCube; ++cubeCnt) {
				default_random_engine dre;
				uniform_real_distribution<> pos_ur(-10.0, 10.0);
				float xPos = pos_ur(dre);
				float yPos = pos_ur(dre);
				m_pCube[cubeCnt]->SetCubeType(player, m_pCube, cubeCnt);
				m_pCube[cubeCnt]->SetPosition(xPos, yPos, player->GetPosition().z + 80.0f);
			}
			// �浹ü NULL
			player->m_pCollider = NULL;
			m_pCube[i]->m_pCollider = NULL;
		}
	}

}

void CScene::Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera) {
	pCamera->SetViewportsAndScissorRects(pd3dCommandList);
	pd3dCommandList->SetGraphicsRootSignature(m_pd3dGraphicsRootSignature);
	pCamera->UpdateShaderVariables(pd3dCommandList);
	for (int i = 0; i < m_nShaders; i++) { 
		m_pShaders[i].Render(pd3dCommandList, pCamera);
	}
}

void CScene::ReleaseUploadBuffers() {
	for (int i = 0; i < m_nShaders; i++)
		m_pShaders[i].ReleaseUploadBuffers();
}

ID3D12RootSignature *CScene::GetGraphicsRootSignature() {
	return(m_pd3dGraphicsRootSignature);
}

ID3D12RootSignature *CScene::CreateGraphicsRootSignature(ID3D12Device *pd3dDevice) {
	ID3D12RootSignature *pd3dGraphicsRootSignature = NULL;
	D3D12_ROOT_PARAMETER pd3dRootParameters[2];
	pd3dRootParameters[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
	pd3dRootParameters[0].Constants.Num32BitValues = 16;
	pd3dRootParameters[0].Constants.ShaderRegister = 0;
	pd3dRootParameters[0].Constants.RegisterSpace = 0;
	pd3dRootParameters[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_VERTEX;
	pd3dRootParameters[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
	pd3dRootParameters[1].Constants.Num32BitValues = 32;
	pd3dRootParameters[1].Constants.ShaderRegister = 1;
	pd3dRootParameters[1].Constants.RegisterSpace = 0;
	pd3dRootParameters[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_VERTEX;
	D3D12_ROOT_SIGNATURE_FLAGS d3dRootSignatureFlags = D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT
		| D3D12_ROOT_SIGNATURE_FLAG_DENY_HULL_SHADER_ROOT_ACCESS |
		D3D12_ROOT_SIGNATURE_FLAG_DENY_DOMAIN_SHADER_ROOT_ACCESS |
		D3D12_ROOT_SIGNATURE_FLAG_DENY_GEOMETRY_SHADER_ROOT_ACCESS |
		D3D12_ROOT_SIGNATURE_FLAG_DENY_PIXEL_SHADER_ROOT_ACCESS;
	D3D12_ROOT_SIGNATURE_DESC d3dRootSignatureDesc;
	::ZeroMemory(&d3dRootSignatureDesc, sizeof(D3D12_ROOT_SIGNATURE_DESC));
	d3dRootSignatureDesc.NumParameters = _countof(pd3dRootParameters);
	d3dRootSignatureDesc.pParameters = pd3dRootParameters;
	d3dRootSignatureDesc.NumStaticSamplers = 0;
	d3dRootSignatureDesc.pStaticSamplers = NULL;
	d3dRootSignatureDesc.Flags = d3dRootSignatureFlags;
	ID3DBlob *pd3dSignatureBlob = NULL;
	ID3DBlob *pd3dErrorBlob = NULL;
	::D3D12SerializeRootSignature(&d3dRootSignatureDesc, D3D_ROOT_SIGNATURE_VERSION_1,
		&pd3dSignatureBlob, &pd3dErrorBlob);
	pd3dDevice->CreateRootSignature(0, pd3dSignatureBlob->GetBufferPointer(),
		pd3dSignatureBlob->GetBufferSize(), __uuidof(ID3D12RootSignature),
		(void **)&pd3dGraphicsRootSignature);
	if (pd3dSignatureBlob) pd3dSignatureBlob->Release();
	if (pd3dErrorBlob) pd3dErrorBlob->Release();
	return(pd3dGraphicsRootSignature);

}