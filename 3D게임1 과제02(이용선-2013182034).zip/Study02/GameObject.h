#pragma once

#include "Mesh.h"
#include "Camera.h"
class CShader;


class CGameObject
{
public:
	CGameObject();
	virtual ~CGameObject();
	void Rotate(XMFLOAT3 *pxmf3Axis, float fAngle);

	// �߰��� ����
	BoundingOrientedBox		m_xmOOBB;
	BoundingOrientedBox		m_xmOOBBTransformed;
	//
	XMFLOAT3 m_xmf3MovingDirection;
	float m_fMovingSpeed;
	CubeType m_eObjectType;

private:
	int m_nReferences = 0;
public:
	//��� ���۸� �����Ѵ�.
	virtual void CreateShaderVariables(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList); 
	//��� ������ ������ �����Ѵ�.
	virtual void UpdateShaderVariables(ID3D12GraphicsCommandList *pd3dCommandList);
	virtual void ReleaseShaderVariables();

	//���� ��ü�� ���� ��ȯ ��Ŀ��� ��ġ ���Ϳ� ����(x-��, y-��, z-��) ���͸� ��ȯ�Ѵ�.
	XMFLOAT3 GetPosition(); 
	XMFLOAT3 GetLook();
	XMFLOAT3 GetUp();
	XMFLOAT3 GetRight();
	//���� ��ü�� ��ġ�� �����Ѵ�.
	void SetPosition(float x, float y, float z); 
	void SetPosition(XMFLOAT3 xmf3Position);
	//���� ��ü�� ���� x-��, y-��, z-�� �������� �̵��Ѵ�.
	void MoveStrafe(float fDistance = 1.0f); 
	void MoveUp(float fDistance = 1.0f);
	void MoveForward(float fDistance = 1.0f);
	//���� ��ü�� ȸ��(x-��, y-��, z-��)�Ѵ�. 
	void Rotate(float fPitch = 10.0f, float fYaw = 10.0f, float fRoll = 10.0f);

	// �߰��Լ� SetOOBB
	void SetOOBB(XMFLOAT3& xmCenter, XMFLOAT3& xmExtents, XMFLOAT4& xmOrientation) { m_xmOOBBTransformed = m_xmOOBB = BoundingOrientedBox(xmCenter, xmExtents, xmOrientation); }
	//

	void AddRef() { m_nReferences++; }
	void Release() { if (--m_nReferences <= 0) delete this; }
protected:
	CMesh *m_pMesh = NULL;
	CShader *m_pShader = NULL;
public:
	XMFLOAT4X4 m_xmf4x4World;
	void ReleaseUploadBuffers();
	virtual void SetMesh(CMesh *pMesh);
	virtual void SetShader(CShader *pShader);
	virtual void Animate(float fTimeElapsed);
	virtual void OnPrepareRender();
	virtual void Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera);
	virtual void Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera, UINT
		nInstances, D3D12_VERTEX_BUFFER_VIEW d3dInstancingBufferView);
	void SetMovingDirection(XMFLOAT3& xmf3MovingDirection) { m_xmf3MovingDirection = Vector3::Normalize(xmf3MovingDirection); }

	XMFLOAT3 playerPosition;
	CGameObject	*m_pCollider;
	void GetPlayerPosition(XMFLOAT3 xmfPlayerPosition) { playerPosition = xmfPlayerPosition; }
	void SetCubeType(CGameObject *m_pPlayer, CGameObject **m_pObjects, int m_nObjects);

	virtual void SetObjectType(CubeType eCubeObjectType) {  }
	virtual void SetMovingSpeed(float fMoveingSpeed) {  }
	virtual void SetRotationSpeed(float fRotationSpeed) {  }
	virtual void SetRotationAxis(XMFLOAT3 xmf3RotationAxis) { }
	//virtual CubeType GetObjectType() { return m_eObjectType; };
	//virtual float GetMovingSpeed() { return m_fMovingSpeed; };
};

class CRotatingObject : public CGameObject {
public: 
	CRotatingObject(); 
	virtual ~CRotatingObject();
private:
	XMFLOAT3 m_xmf3RotationAxis; 
	float m_fRotationSpeed;
	float m_fMovingSpeed;
	CubeType m_eObjectType;
public: 
	virtual void SetObjectType(CubeType eCubeObjectType)  { m_eObjectType = eCubeObjectType; }
	//virtual CubeType GetObjectType() { return m_eObjectType; }
	virtual void SetMovingSpeed(float fMoveingSpeed) { m_fMovingSpeed = fMoveingSpeed; }
	//virtual float GetMovingSpeed() { return m_fMovingSpeed; }
	virtual void SetRotationSpeed(float fRotationSpeed) { m_fRotationSpeed = fRotationSpeed; }
	virtual void SetRotationAxis(XMFLOAT3 xmf3RotationAxis) { m_xmf3RotationAxis = xmf3RotationAxis; }

	virtual void Animate(float fTimeElapsed);
};

class CWallObject : public CGameObject {
private:
	int cnt = 0;
	XMFLOAT4 m_pxmf4WallPlanes[4];
public:
	CWallObject();
	virtual ~CWallObject();
	void wallCnt() { cnt = cnt + 1; }
	void SetPlanes() {
		m_pxmf4WallPlanes[0] = XMFLOAT4(+1.0f, 0.0f, 0.0f, 0.0f);
		m_pxmf4WallPlanes[1] = XMFLOAT4(-1.0f, 0.0f, 0.0f, 0.0f);
		m_pxmf4WallPlanes[2] = XMFLOAT4(0.0f, +1.0f, 0.0f, 0.0f);
		m_pxmf4WallPlanes[3] = XMFLOAT4(0.0f, -1.0f, 0.0f, 0.0f);
	};
	virtual void Animate(float fTimeElapsed);
};

class CBullet : public CGameObject 
{
private:
	XMFLOAT3 m_xmf3RotationAxis;
	float m_fRotationSpeed;
	float m_fMovingSpeed;
	CubeType m_eObjectType;
public:
	CBullet();
	virtual ~CBullet();
	virtual void SetObjectType(CubeType eCubeObjectType) { m_eObjectType = eCubeObjectType; }
	virtual void SetMovingSpeed(float fMoveingSpeed) { m_fMovingSpeed = fMoveingSpeed; }
	virtual void SetRotationSpeed(float fRotationSpeed) { m_fRotationSpeed = fRotationSpeed; }
	virtual void SetRotationAxis(XMFLOAT3 xmf3RotationAxis) { m_xmf3RotationAxis = xmf3RotationAxis; }
	virtual void Animate(float fTimeElapsed);
};