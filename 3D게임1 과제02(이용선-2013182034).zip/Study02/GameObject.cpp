#include "stdafx.h"
#include "GameObject.h"
#include "Scene.h"
#include "Player.h"
#include "Shader.h"


CGameObject::CGameObject()
{
	XMStoreFloat4x4(&m_xmf4x4World, XMMatrixIdentity());
}

CGameObject::~CGameObject()
{
	if (m_pMesh) m_pMesh->Release();
	if (m_pShader) {
		m_pShader->ReleaseShaderVariables();
		m_pShader->Release();
	}
}

void CGameObject::Rotate(XMFLOAT3 * pxmf3Axis, float fAngle)
{
	XMMATRIX mtxRotate = XMMatrixRotationAxis(XMLoadFloat3(pxmf3Axis), XMConvertToRadians(fAngle));
	m_xmf4x4World = Matrix4x4::Multiply(mtxRotate, m_xmf4x4World);
}

void CGameObject::CreateShaderVariables(ID3D12Device * pd3dDevice, ID3D12GraphicsCommandList * pd3dCommandList)
{
}

void CGameObject::UpdateShaderVariables(ID3D12GraphicsCommandList * pd3dCommandList)
{
	XMFLOAT4X4 xmf4x4World;
	XMStoreFloat4x4(&xmf4x4World, XMMatrixTranspose(XMLoadFloat4x4(&m_xmf4x4World)));
	//��ü�� ���� ��ȯ ����� ��Ʈ ���(32-��Ʈ ��)�� ���Ͽ� ���̴� ����(��� ����)�� �����Ѵ�.
	pd3dCommandList->SetGraphicsRoot32BitConstants(0, 16, &xmf4x4World, 0);
}

void CGameObject::ReleaseShaderVariables()
{
}

void CGameObject::SetShader(CShader *pShader) {
	if (m_pShader) m_pShader->Release();
	m_pShader = pShader;
	if (m_pShader) m_pShader->AddRef();
}

void CGameObject::Animate(float fTimeElapsed)
{
	m_xmOOBBTransformed.Transform(m_xmOOBB, XMLoadFloat4x4(&m_xmf4x4World));
	XMStoreFloat4(&m_xmOOBBTransformed.Orientation, XMQuaternionNormalize(XMLoadFloat4(&m_xmOOBBTransformed.Orientation)));
}

void CGameObject::OnPrepareRender()
{
}

void CGameObject::Render(ID3D12GraphicsCommandList * pd3dCommandList, CCamera *pCamera)
{
	OnPrepareRender();
	//��ü�� ������ ���̴� ����(��� ����)�� �����Ѵ�. 
	UpdateShaderVariables(pd3dCommandList);
	if (m_pShader) m_pShader->Render(pd3dCommandList, pCamera);
	if (m_pMesh) m_pMesh->Render(pd3dCommandList);
}

//�ν��Ͻ� ���� ���� �並 ����Ͽ� �޽��� �������Ѵ�. 
void CGameObject::Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera,
	UINT nInstances, D3D12_VERTEX_BUFFER_VIEW d3dInstancingBufferView)
{
	OnPrepareRender();
	if (m_pMesh) m_pMesh->Render(pd3dCommandList, nInstances, d3dInstancingBufferView);
}

void CGameObject::SetCubeType(CGameObject *m_pPlayer, CGameObject **m_pCube, int m_nObjects)
{
	XMFLOAT3 m_nPlayer = m_pPlayer->GetPosition();

	default_random_engine dre;
	uniform_int_distribution<> dir_ui(0, 1);
	uniform_int_distribution<> crossDir_ui(0, 5);
	uniform_int_distribution<> type(0, 2);
	uniform_real_distribution<> pos_ur(-15.0, 15.0);
	uniform_real_distribution<> spd_ur(0.0, 0.1);
	dre.seed(chrono::system_clock::now().time_since_epoch().count());

	CubeType objectsType = (CubeType)type(dre);
	//CubeType objectsType = (CubeType)2;
	float xPos = pos_ur(dre);
	float yPos = pos_ur(dre);
	int dir = dir_ui(dre);
	float speed = spd_ur(dre);
	
	m_pCube[m_nObjects]->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
		XMFLOAT3(4.0f, 4.0f, 4.0f),
		XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	
	m_xmf4x4World._11 = 1.0f; m_xmf4x4World._12 = 0.0f; m_xmf4x4World._13 = 0.0f; m_xmf4x4World._14 = 0.0f; 
	m_xmf4x4World._21 = 0.0f; m_xmf4x4World._22 = 1.0f; m_xmf4x4World._23 = 0.0f; m_xmf4x4World._24 = 0.0f;
	m_xmf4x4World._31 = 0.0f; m_xmf4x4World._32 = 0.0f; m_xmf4x4World._33 = 1.0f; m_xmf4x4World._34 = 0.0f;

	switch (objectsType)
	{
	case XPOS:
		m_pCube[m_nObjects]->SetObjectType(objectsType);
		
		if (dir == 0) {	m_pCube[m_nObjects]->SetMovingSpeed(speed);
						m_pCube[m_nObjects]->SetRotationAxis(XMFLOAT3(1.0f, 0.0f, 0.0f)); }
		else {			m_pCube[m_nObjects]->SetMovingSpeed(speed * -1.0f);
						m_pCube[m_nObjects]->SetRotationAxis(XMFLOAT3(-1.0f, 0.0f, 0.0f)); }
		break;
	case YPOS:
		m_pCube[m_nObjects]->SetObjectType(objectsType);
		m_pCube[m_nObjects]->SetPosition(xPos, yPos, 10.0f + m_nPlayer.z + 80.0f);
		if (dir == 0) {	m_pCube[m_nObjects]->SetMovingSpeed(speed);
						m_pCube[m_nObjects]->SetRotationAxis(XMFLOAT3(0.0f, 1.0f, 0.0f)); }
		else {			m_pCube[m_nObjects]->SetMovingSpeed(speed * -1.0f);
						m_pCube[m_nObjects]->SetRotationAxis(XMFLOAT3(0.0f, -1.0f, 0.0f)); }
		break;
	case ZPOS:
		m_pCube[m_nObjects]->SetObjectType(objectsType);
		m_pCube[m_nObjects]->SetPosition(xPos, yPos, 10.0f + m_nPlayer.z + 80.0f);
		if (dir == 0) { m_pCube[m_nObjects]->SetMovingSpeed(speed);
					    m_pCube[m_nObjects]->SetRotationAxis(XMFLOAT3(0.0f, 0.0f, 1.0f)); }
		else {			m_pCube[m_nObjects]->SetMovingSpeed(speed * -1.0f);
						m_pCube[m_nObjects]->SetRotationAxis(XMFLOAT3(0.0f, 0.0f, -1.0f)); }
		break;
		/*
	case CROSSPOS:
		int crossDir = crossDir_ui(dre);
		m_pObjects[m_nObjects].SetColor(RGB(255, 0, 255));
		if (crossDir == 0) {
			m_pObjects[m_nObjects].SetMovingDirection(XMFLOAT3(1.0f, -1.0f, 0.0f));
			m_pObjects[m_nObjects].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));
		}
		else if (crossDir == 1) {
			m_pObjects[m_nObjects].SetMovingDirection(XMFLOAT3(1.0f, 1.0f, 0.0f));
			m_pObjects[m_nObjects].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));
		}
		else if (crossDir == 2) {
			m_pObjects[m_nObjects].SetMovingDirection(XMFLOAT3(1.0f, -1.0f, 1.0f));
			m_pObjects[m_nObjects].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));
		}
		else if (crossDir == 3) {
			m_pObjects[m_nObjects].SetMovingDirection(XMFLOAT3(1.0f, 1.0f, 1.0f));
			m_pObjects[m_nObjects].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));
		}
		else if (crossDir == 4) {
			m_pObjects[m_nObjects].SetMovingDirection(XMFLOAT3(1.0f, -1.0f, -1.0f));
			m_pObjects[m_nObjects].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));
		}
		else if (crossDir == 5) {
			m_pObjects[m_nObjects].SetMovingDirection(XMFLOAT3(1.0f, 1.0f, -1.0f));
			m_pObjects[m_nObjects].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));
		}
		m_pObjects[m_nObjects].SetPosition(xPos, yPos, m_nPlayer.z + 80.0f);
		break;
		*/
	}
	
	cout << endl;
}

void CGameObject::SetMesh(CMesh *pMesh) {
	if (m_pMesh) m_pMesh->Release();
	m_pMesh = pMesh;
	if (m_pMesh) m_pMesh->AddRef();
}

void CGameObject::ReleaseUploadBuffers() {
	//���� ���۸� ���� ���ε� ���۸� �Ҹ��Ų��.
	if (m_pMesh) m_pMesh->ReleaseUploadBuffers();
}

void CGameObject::SetPosition(float x, float y, float z) {
	m_xmf4x4World._41 = x;
	m_xmf4x4World._42 = y;
	m_xmf4x4World._43 = z;
}
void CGameObject::SetPosition(XMFLOAT3 xmf3Position) {
	SetPosition(xmf3Position.x, xmf3Position.y, xmf3Position.z);
}
XMFLOAT3 CGameObject::GetPosition() {
	return(XMFLOAT3(m_xmf4x4World._41, m_xmf4x4World._42, m_xmf4x4World._43));
}
//���� ��ü�� ���� z-�� ���͸� ��ȯ�Ѵ�.
XMFLOAT3 CGameObject::GetLook() {
	return(Vector3::Normalize(XMFLOAT3(m_xmf4x4World._31, m_xmf4x4World._32, m_xmf4x4World._33)));
}

//���� ��ü�� ���� y-�� ���͸� ��ȯ�Ѵ�. 
XMFLOAT3 CGameObject::GetUp() {
	return(Vector3::Normalize(XMFLOAT3(m_xmf4x4World._21, m_xmf4x4World._22, m_xmf4x4World._23)));
}

//���� ��ü�� ���� x-�� ���͸� ��ȯ�Ѵ�. 
XMFLOAT3 CGameObject::GetRight() {
	return(Vector3::Normalize(XMFLOAT3(m_xmf4x4World._11, m_xmf4x4World._12, m_xmf4x4World._13)));
}

//���� ��ü�� ���� x-�� �������� �̵��Ѵ�.
void CGameObject::MoveStrafe(float fDistance) {
	XMFLOAT3 xmf3Position = GetPosition();
	XMFLOAT3 xmf3Right = GetRight();
	xmf3Position = Vector3::Add(xmf3Position, xmf3Right, fDistance);
	CGameObject::SetPosition(xmf3Position);
}


//���� ��ü�� ���� y-�� �������� �̵��Ѵ�. 
void CGameObject::MoveUp(float fDistance) {
	XMFLOAT3 xmf3Position = GetPosition();
	XMFLOAT3 xmf3Up = GetUp();
	xmf3Position = Vector3::Add(xmf3Position, xmf3Up, fDistance);
	CGameObject::SetPosition(xmf3Position);
}

//���� ��ü�� ���� z-�� �������� �̵��Ѵ�. 
void CGameObject::MoveForward(float fDistance) {
	XMFLOAT3 xmf3Position = GetPosition();
	XMFLOAT3 xmf3Look = GetLook();
	xmf3Position = Vector3::Add(xmf3Position, xmf3Look, fDistance);
	CGameObject::SetPosition(xmf3Position);
}

//���� ��ü�� �־��� ������ ȸ���Ѵ�. 
void CGameObject::Rotate(float fPitch, float fYaw, float fRoll) {
	XMMATRIX mtxRotate = XMMatrixRotationRollPitchYaw(XMConvertToRadians(fPitch),
		XMConvertToRadians(fYaw), XMConvertToRadians(fRoll));
	m_xmf4x4World = Matrix4x4::Multiply(mtxRotate, m_xmf4x4World);
}

CRotatingObject::CRotatingObject()
{
	XMStoreFloat4x4(&m_xmf4x4World, XMMatrixIdentity());
	m_xmf3RotationAxis = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_fRotationSpeed = 90.0f;
}

CRotatingObject::~CRotatingObject()
{
}

void CRotatingObject::Animate(float fTimeElapsed)
{
	CGameObject::Animate(fTimeElapsed);
	CGameObject::Rotate(&m_xmf3RotationAxis, m_fRotationSpeed * fTimeElapsed);
	if		(m_eObjectType == (CubeType)0) CGameObject::MoveStrafe(m_fMovingSpeed);
	else if (m_eObjectType == (CubeType)1) CGameObject::MoveUp(m_fMovingSpeed);
	else if (m_eObjectType == (CubeType)2) CGameObject::MoveForward(m_fMovingSpeed);
	//if (objectType == (CubeType)3) CGameObject::MoveStrafe(m_fMovingSpeed);
}

CWallObject::CWallObject() : CGameObject()
{
	XMStoreFloat4x4(&m_xmf4x4World, XMMatrixIdentity());
}

CWallObject::~CWallObject()
{
	CGameObject::ReleaseUploadBuffers();
	CGameObject::ReleaseShaderVariables();
	CGameObject::Release();
}

void CWallObject::Animate(float fTimeElapsed)
{
	XMFLOAT3 wallPos = CGameObject::GetPosition();

	if (CGameObject::playerPosition.z > (wallPos.z + 20.0f)) {
		SetPosition(0.0f, 0.0f, wallPos.z + 400.0f);
		SetOOBB(XMFLOAT3(0.0f, 0.0f, wallPos.z + 400.0f),
			XMFLOAT3(100.0f, 100.0f, 10.0f),
			XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	}
	CGameObject::Animate(fTimeElapsed);

}

CBullet::CBullet()
{
	XMStoreFloat4x4(&m_xmf4x4World, XMMatrixIdentity());
}

CBullet::~CBullet()
{
}

void CBullet::Animate(float fTimeElapsed)
{
	CGameObject::Animate(fTimeElapsed);
	CGameObject::Rotate(&m_xmf3RotationAxis, m_fRotationSpeed * fTimeElapsed);
	CGameObject::MoveForward(m_fMovingSpeed);
}
