//-----------------------------------------------------------------------------
// File: CGameFramework.cpp
//-----------------------------------------------------------------------------

#include "stdafx.h"
#include "GameFramework.h"
int cnt = 0;
bool Particle_on = false;

CGameFramework::CGameFramework()
{
	m_hInstance = NULL;
	m_hWnd = NULL;

	m_hDCFrameBuffer = NULL;
	m_hBitmapFrameBuffer = NULL;

	m_bActive = true;

	m_nObjects = 0;
}

CGameFramework::~CGameFramework()
{
}

bool CGameFramework::OnCreate(HINSTANCE hInstance, HWND hMainWnd)
{
	srand(timeGetTime());

	m_hInstance = hInstance;
	m_hWnd = hMainWnd;

	RECT rcClient;
	GetClientRect(m_hWnd, &rcClient);

	m_pPlayer = new CPlayer();
	m_pPlayer->m_pCamera->SetViewport(rcClient.left, rcClient.top, rcClient.right - rcClient.left, rcClient.bottom - rcClient.top);

	BuildFrameBuffer();

	BuildObjects();

	SetupGameState();

	return(true);
}

void CGameFramework::BuildFrameBuffer()
{
	HDC hDC = ::GetDC(m_hWnd);

	RECT rcClient;
	GetClientRect(m_hWnd, &rcClient);

	m_hDCFrameBuffer = ::CreateCompatibleDC(hDC);
	m_hBitmapFrameBuffer = ::CreateCompatibleBitmap(hDC, (rcClient.right - rcClient.left) + 1, (rcClient.bottom - rcClient.top) + 1);
	::SelectObject(m_hDCFrameBuffer, m_hBitmapFrameBuffer);

	::ReleaseDC(m_hWnd, hDC);
	::SetBkMode(m_hDCFrameBuffer, TRANSPARENT);
}

void CGameFramework::ClearFrameBuffer(DWORD dwColor)
{
	HBRUSH hBrush = ::CreateSolidBrush(dwColor);
	HBRUSH hOldBrush = (HBRUSH)::SelectObject(m_hDCFrameBuffer, hBrush);
	::Rectangle(m_hDCFrameBuffer, m_pPlayer->m_pCamera->m_Viewport.m_xStart, m_pPlayer->m_pCamera->m_Viewport.m_yStart, m_pPlayer->m_pCamera->m_Viewport.m_nWidth, m_pPlayer->m_pCamera->m_Viewport.m_nHeight);
	::SelectObject(m_hDCFrameBuffer, hOldBrush);
	::DeleteObject(hBrush);
}

void CGameFramework::PresentFrameBuffer()
{
	HDC hDC = ::GetDC(m_hWnd);
	::BitBlt(hDC, m_pPlayer->m_pCamera->m_Viewport.m_xStart, m_pPlayer->m_pCamera->m_Viewport.m_yStart, m_pPlayer->m_pCamera->m_Viewport.m_nWidth, m_pPlayer->m_pCamera->m_Viewport.m_nHeight, m_hDCFrameBuffer, m_pPlayer->m_pCamera->m_Viewport.m_xStart, m_pPlayer->m_pCamera->m_Viewport.m_yStart, SRCCOPY);
	::ReleaseDC(m_hWnd, hDC);
}

void CGameFramework::SetupGameState()
{
}

void CGameFramework::SetupRenderStates()
{
}

void CGameFramework::BuildObjects()
{
	//����
	CAirplaneMesh *pAirplaneMesh = new CAirplaneMesh(6.0f, 6.0f, 1.0f);
	m_pPlayer->SetPosition(0.0f, 0.0f, -20.0f);
	m_pPlayer->SetMesh(pAirplaneMesh);
	m_pPlayer->SetColor(RGB(0, 0, 255));
	//3��Ī ī�޶�
	m_pPlayer->SetCameraOffset(XMFLOAT3(0.0f, 5.0f, -15.0f));
	//OOBB
	m_pPlayer->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f), 
					   XMFLOAT3(2.0f, 1.0f, 2.0f), 
					   XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));

	// �� 
	CWallMesh *pWallCubeMesh = new CWallMesh(30.0f, 30.0f, 20.0f);
	m_nWall = 12;
	m_pWall = new CGameObject[m_nWall];
	for (int m_pWall_cnt = 0; m_pWall_cnt < 12; ++m_pWall_cnt) {
		m_pWall[m_pWall_cnt].SetPosition(0.0f, 0.0f, 0.0f + (m_pWall_cnt * 20.0f));	// z 220
		m_pWall[m_pWall_cnt].SetMesh(pWallCubeMesh);
		m_pWall[m_pWall_cnt].SetColor(RGB(0, 0, 0));
		m_pWall[m_pWall_cnt].SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f + (m_pWall_cnt * 20.0f)),
			XMFLOAT3(15.0f, 15.0f, 10.0f),
			XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	}

	// ���� ������
	m_pxmf4WallPlanes[0] = XMFLOAT4(+1.0f, 0.0f, 0.0f, 15.0f);
	m_pxmf4WallPlanes[1] = XMFLOAT4(-1.0f, 0.0f, 0.0f, 15.0f);
	m_pxmf4WallPlanes[2] = XMFLOAT4(0.0f, +1.0f, 0.0f, 15.0f);
	m_pxmf4WallPlanes[3] = XMFLOAT4(0.0f, -1.0f, 0.0f, 15.0f);
	//m_pxmf4WallPlanes[4] = XMFLOAT4(0.0f, 0.0f, +1.0f, 10.0f);
	//m_pxmf4WallPlanes[5] = XMFLOAT4(0.0f, 0.0f, -1.0f, 10.0f);

	// ť��
	/*
	1. Ÿ�� ( x, y, z, �밢�� )
	2. Ÿ�Ժ��� ó�� �̵� ( ����, ���� : 0, 1 / x - �¿�, y - ���Ʒ�, z - �յ�, �밢�� - ? )
	3. ������ Ÿ�Ժ��� ���� ( x - 255, 0, 0 / y - 0, 255, 0 / z - 0, 0, 255 / �밢�� - 255, 255, 0 )
	4. ������ ( ���� , ���� : -12.0 ~ 12.0 )
	5. �̵� ���ǵ� ( ���� , ���� : 0.000 ~ 0.10 )
	*/

	default_random_engine dre;
	uniform_int_distribution<> dir_ui(0, 1);
	uniform_int_distribution<> crossDir_ui(0, 5);
	uniform_int_distribution<> type_ui(0, 3);
	uniform_real_distribution<> pos_ur(-12.0, 12.0);
	uniform_real_distribution<> spd_ur(0.0, 0.1);
	CCubeMesh *pObjectCubeMesh = new CCubeMesh(4.0f, 4.0f, 4.0f);
	dre.seed(chrono::system_clock::now().time_since_epoch().count());
	
	m_nObjects = 9;
	m_pObjects = new CGameObject[m_nObjects];

	for (int i = 0; i < m_nObjects; ++i) {
		CubeType type_Objects = (CubeType)type_ui(dre);
		int dir = dir_ui(dre);
		float xPos = pos_ur(dre);
		float yPos = pos_ur(dre);
		float speed = spd_ur(dre);
		switch (type_Objects)
		{
		case CubeType::XPOS:
			m_pObjects[i].SetMesh(pObjectCubeMesh);
			m_pObjects[i].SetColor(RGB(255, 0, 0));
			m_pObjects[i].SetPosition(xPos, yPos, 10.0f + (xPos));
			if (dir == 0)		{m_pObjects[i].SetMovingDirection(XMFLOAT3(1.0f, 0.0f, 0.0f));
								 m_pObjects[i].SetRotationAxis(XMFLOAT3(1.0f, 0.0f, 0.0f));}
			else if (dir == 1)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(-1.0f, 0.0f, 0.0f));
								 m_pObjects[i].SetRotationAxis(XMFLOAT3(-1.0f, 0.0f, 0.0f));}
			m_pObjects[i].SetRotationSpeed(0.1f);
			m_pObjects[i].SetMovingSpeed(speed);
			m_pObjects[i].SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
								  XMFLOAT3(2.0f, 2.0f, 2.0f),
								  XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			break;
		case CubeType::YPOS:
			m_pObjects[i].SetMesh(pObjectCubeMesh);
			m_pObjects[i].SetColor(RGB(0, 255, 0));
			m_pObjects[i].SetPosition(xPos, yPos, 10.0f + (xPos));
			if (dir == 0)		{m_pObjects[i].SetMovingDirection(XMFLOAT3(0.0f, 1.0f, 0.0f));
								 m_pObjects[i].SetRotationAxis(XMFLOAT3(0.0f, 1.0f, 0.0f));}
			else if (dir == 1)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(0.0f, -1.0f, 0.0f));
								 m_pObjects[i].SetRotationAxis(XMFLOAT3(0.0f, -1.0f, 0.0f));}
			m_pObjects[i].SetRotationSpeed(0.1f);
			m_pObjects[i].SetMovingSpeed(speed);
			m_pObjects[i].SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
								  XMFLOAT3(2.0f, 2.0f, 2.0f),
								  XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			break;
		case CubeType::ZPOS:
			m_pObjects[i].SetMesh(pObjectCubeMesh);
			m_pObjects[i].SetColor(RGB(0, 0, 255));
			m_pObjects[i].SetPosition(xPos, yPos, 10.0f + (xPos));
			if (dir == 0)		{m_pObjects[i].SetMovingDirection(XMFLOAT3(0.0f, 0.0f, 1.0f));
								 m_pObjects[i].SetRotationAxis(XMFLOAT3(0.0f, 0.0f, 1.0f));}
			else if (dir == 1)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(0.0f, 0.0f, -1.0f));
								 m_pObjects[i].SetRotationAxis(XMFLOAT3(0.0f, 0.0f, -1.0f));}
			m_pObjects[i].SetRotationSpeed(0.1f);
			m_pObjects[i].SetMovingSpeed(speed);
			m_pObjects[i].SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
								  XMFLOAT3(2.0f, 2.0f, 2.0f),
								  XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			break;
		case CubeType::CROSSPOS:
			int crossDir = crossDir_ui(dre);

			m_pObjects[i].SetMesh(pObjectCubeMesh);
			m_pObjects[i].SetColor(RGB(255, 0, 255));
			m_pObjects[i].SetPosition(xPos, yPos, 10.0f + (xPos));
			if		(crossDir == 0)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(1.0f, -1.0f, 0.0f));
									 m_pObjects[i].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));}
			else if (crossDir == 1)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(1.0f, 1.0f, 0.0f)); 
									 m_pObjects[i].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));}
			else if (crossDir == 2)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(1.0f, -1.0f, 1.0f));
									 m_pObjects[i].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));}
			else if (crossDir == 3)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(1.0f, 1.0f, 1.0f)); 
									 m_pObjects[i].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));}
			else if (crossDir == 4) {m_pObjects[i].SetMovingDirection(XMFLOAT3(1.0f, -1.0f, -1.0f)); 
									 m_pObjects[i].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));}
			else if (crossDir == 5)	{m_pObjects[i].SetMovingDirection(XMFLOAT3(1.0f, 1.0f, -1.0f));
									 m_pObjects[i].SetRotationAxis(XMFLOAT3(1.0f, -1.0f, 0.0f));}
			m_pObjects[i].SetRotationSpeed(0.1f);
			m_pObjects[i].SetMovingSpeed(speed);
			m_pObjects[i].SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
								  XMFLOAT3(2.0f, 2.0f, 2.0f),
								  XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			break;
		}
	}

	// ��ƼŬ
	
	CCubeMesh *pObjectParticleMesh = new CCubeMesh(0.5, 0.5, 0.5);
	
	m_pParticle = new CGameObject[50];

	for (int i = 0; i < 50; ++i) {
		m_pParticle[i].SetMesh(pObjectParticleMesh);
		m_pParticle[i].SetRotationAxis(XMFLOAT3(0.0f, 0.0f, 1.0f));
		m_pParticle[i].SetRotationSpeed(0.3f);
		m_pParticle[i].SetMovingSpeed(0.005f);
	}

	// �Ѿ�
	CCubeMesh *pObjectBulletMesh = new CCubeMesh(1.0f, 1.0f, 1.0f);
	float m_nBulletSpeed = 0.2f;
	m_BulletTimer = true;

	m_pBullet = new CGameObject();

	m_pBullet->SetMesh(pObjectBulletMesh);
	m_pBullet->SetColor(RGB(0,255,255));
	m_pBullet->SetRotationAxis(XMFLOAT3(0.0f, 0.0f, 1.0f));
	m_pBullet->SetRotationSpeed(0.3f);
	m_pBullet->SetMovingSpeed(m_nBulletSpeed);
	m_pBullet->SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f),
						XMFLOAT3(0.5f, 0.5f, 0.5f),
						XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));

}

void CGameFramework::ReleaseObjects()
{
	if (m_pObjects) delete[] m_pObjects;
	m_pObjects = NULL;
}

void CGameFramework::OnDestroy()
{
	ReleaseObjects();

	if (m_hBitmapFrameBuffer) ::DeleteObject(m_hBitmapFrameBuffer);
	if (m_hDCFrameBuffer) ::DeleteDC(m_hDCFrameBuffer);

	if (m_hWnd) DestroyWindow(m_hWnd);
}
//Ű �Է�
void CGameFramework::ProcessInput()
{
	static UCHAR pKeyBuffer[256];
	DWORD dwDirection = 0;
	if (GetKeyboardState(pKeyBuffer))
	{
		if ((pKeyBuffer[VK_UP] & 0xF0)) dwDirection |= DIR_FORWARD;
		

		if ((pKeyBuffer[VK_DOWN] & 0xF0)) dwDirection |= DIR_BACKWARD;
		if ((pKeyBuffer[VK_LEFT] & 0xF0)) dwDirection |= DIR_LEFT;
		if ((pKeyBuffer[VK_RIGHT] & 0xF0)) dwDirection |= DIR_RIGHT;
		
		if ((pKeyBuffer[VK_PRIOR] & 0xF0)) dwDirection |= DIR_UP;
		if ((pKeyBuffer[VK_NEXT] & 0xF0)) dwDirection |= DIR_DOWN;
		
		// �����̽��� �Է½�
		if (pKeyBuffer[VK_SPACE] & 0xF0) dwDirection |= DIR_BULLET;
	}
	float cxDelta = 0.0f, cyDelta = 0.0f;
	POINT ptCursorPos;
	if (GetCapture() == m_hWnd)
	{
		SetCursor(NULL);
		GetCursorPos(&ptCursorPos);
		cxDelta = (float)(ptCursorPos.x - m_ptOldCursorPos.x) / 3.0f;
		cyDelta = (float)(ptCursorPos.y - m_ptOldCursorPos.y) / 3.0f;
		SetCursorPos(m_ptOldCursorPos.x, m_ptOldCursorPos.y);
	}
	if ((dwDirection != 0) || (cxDelta != 0.0f) || (cyDelta != 0.0f))
	{
		if (cxDelta || cyDelta)
		{
			// ���� ��ư ��� ����
			/*
			if (pKeyBuffer[VK_RBUTTON] & 0xF0)
				m_pPlayer->Rotate(cyDelta, 0.0f, -cxDelta);
			else
			*/
				m_pPlayer->Rotate(cyDelta, cxDelta, 0.0f);

		}
		// �÷��̾� �̵�
		if (dwDirection != DIR_BULLET) {
			if (m_pPlayer->GetUp().z > -0.1)
				m_pPlayer->Move(dwDirection, 0.1f);
		}
		// �Ѿ� ����
		if (dwDirection == DIR_BULLET && m_BulletTimer == true) {
			// ���� �÷��̾� ��ġ
			m_pBullet->SetPosition(m_pPlayer->GetPosition());
			// �ٶ󺸰� �ִ� ����
			m_pBullet->SetMovingDirection(m_pPlayer->GetUp());
			// ����Ʈ�� �߰�.
			m_vBullets.push_back(*m_pBullet);
		}
	}
	m_pPlayer->Update(0.00516f);
}

//������Ʈ
void CGameFramework::AnimateObjects()
{
	default_random_engine dre;
	uniform_int_distribution<> xdir_ul(-10.0, 10.0);
	uniform_int_distribution<> ydir_ul(-10.0, 10.0);
	uniform_int_distribution<> zdir_ul(-10.0, 10.0);

	dre.seed(chrono::system_clock::now().time_since_epoch().count());

	for (int i = 0; i < m_nObjects; i++) m_pObjects[i].Animate();

	// ť�� - �� �浹(������ �ڵ�)
	for (int i = 0; i < m_nObjects; i++)
	{
		ContainmentType containType = m_pWall->m_xmOOBB.Contains(m_pObjects[i].m_xmOOBB);
		switch (containType)
		{
		// �ܺ�
		case DISJOINT:
		{
			int nPlaneIndex = -1;
			for (int j = 0; j < 6; j++)
			{
				PlaneIntersectionType intersectType = m_pObjects[i].m_xmOOBB.Intersects(XMLoadFloat4(&m_pxmf4WallPlanes[j]));
				if (intersectType == BACK)
				{
					nPlaneIndex = j;
					break;
				}
			}
			if (nPlaneIndex != -1)
			{
				XMVECTOR xmvNormal = XMVectorSet(m_pxmf4WallPlanes[nPlaneIndex].x, m_pxmf4WallPlanes[nPlaneIndex].y, m_pxmf4WallPlanes[nPlaneIndex].z, 0.0f);
				XMVECTOR xmvReflect = XMVector3Reflect(XMLoadFloat3(&m_pObjects[i].m_xmf3MovingDirection), xmvNormal);
				XMStoreFloat3(&m_pObjects[i].m_xmf3MovingDirection, xmvReflect);
			}
			break;
		}
		// �浹
		case INTERSECTS:
		{
			int nPlaneIndex = -1;
			// �յ� �浹 ����.. �������� j < 6
			for (int j = 0; j < 6; j++)
			{
				PlaneIntersectionType intersectType = m_pObjects[i].m_xmOOBB.Intersects(XMLoadFloat4(&m_pxmf4WallPlanes[j]));
				if (intersectType == INTERSECTING)
				{
					nPlaneIndex = j;
					break;
				}
			}
			if (nPlaneIndex != -1)
			{
				XMVECTOR xmvNormal = XMVectorSet(m_pxmf4WallPlanes[nPlaneIndex].x, m_pxmf4WallPlanes[nPlaneIndex].y, m_pxmf4WallPlanes[nPlaneIndex].z, 0.0f);
				XMVECTOR xmvReflect = XMVector3Reflect(XMLoadFloat3(&m_pObjects[i].m_xmf3MovingDirection), xmvNormal);
				XMStoreFloat3(&m_pObjects[i].m_xmf3MovingDirection, xmvReflect);
			}
			break;
		}
		// ����
		case CONTAINS:
			break;
		}
	}

	// ť�� - �浹ü �ʱ�ȭ
	for (int i = 0; i < m_nObjects; i++) m_pObjects[i].m_pCollider = NULL;

	// �÷��̾� - ť�� �浹 üũ
	for (int i = 0; i < m_nObjects; ++i) {
		if (m_pObjects[i].m_xmOOBB.Intersects(m_pPlayer->m_xmOOBB))
		{
			m_pObjects[i].m_pCollider = m_pPlayer;
			m_pPlayer->m_pCollider = &m_pObjects[i];
		}
	}

	// �÷��̾� - ť�� �浹 ó��
	for (int i = 0; i < m_nObjects; i++)
	{
		//
		if (m_pObjects[i].m_pCollider && m_pPlayer->m_pCollider->m_pCollider)
		{
			// �÷��̾� ��ġ �ʱ�ȭ
			m_pPlayer->SetPosition(0.0f, 0.0f, 0.0f);

			// �� �ʱ�ȭ
			for (int m_pWall_cnt = 0; m_pWall_cnt < 12; ++m_pWall_cnt) {
				m_pWall[m_pWall_cnt].SetPosition(0.0f, 0.0f, 0.0f + (m_pWall_cnt * 20));
				m_pWall[m_pWall_cnt].SetOOBB(XMFLOAT3(0.0f, 0.0f, 0.0f + (m_pWall_cnt * 20.0f)),
					XMFLOAT3(15.0f, 15.0f, 10.0f),
					XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			}
			cnt = 0;

			// ť�� �ʱ�ȭ
			for (int m_nCube_cnt = 0; m_nCube_cnt < m_nObjects; ++m_nCube_cnt){
				m_pObjects[m_nCube_cnt].SetCubeType(m_pPlayer, m_pObjects, m_nCube_cnt);
			}

			// �浹ü NULL
			m_pPlayer->m_pCollider->m_pCollider = NULL;
			m_pObjects[i].m_pCollider = NULL;
		}
	}

	// �÷��̾� - �� �浹ó��
	for (int i = 0; i < m_nWall; ++i) {
		// � ���ȿ� �÷��̾ �ִ°�?
		if (m_pWall[i].m_xmOOBB.Contains(m_pPlayer->m_xmOOBB)){
			// � ���̶� �浹?
			for (int j = 0; j < 4; ++j) {
				if (m_pPlayer->m_xmOOBB.Intersects(XMLoadFloat4(&m_pxmf4WallPlanes[j]))) {
					XMFLOAT3 dir;
					// �浹�� ���� ���� ���͸� �޾Ƽ� �ݴ�� �ӵ��� ���� ������ �о������.
					switch (j)
					{
					case 0:
						dir = XMFLOAT3(+1.0f, 0.0f, 0.0f);
						m_pPlayer->Move(dir, 0.2f);
						break;
					case 1:
						dir = XMFLOAT3(-1.0f, 0.0f, 0.0f);
						m_pPlayer->Move(dir, 0.2f);
						break;
					case 2:
						dir = XMFLOAT3(0.0f, +1.0f, 0.0f);
						m_pPlayer->Move(dir, 0.2f);
						break;
					case 3:
						dir = XMFLOAT3(0.0f, -1.0f, 0.0f);
						m_pPlayer->Move(dir, 0.2f);
						break;
					}
				}
			}
		}
	}

	// ť�� - �Ѿ� �浹 üũ
	for (int i = 0; i < m_nObjects; ++i) {
		for (auto iter = m_vBullets.begin(); iter != m_vBullets.end(); ++iter) {
			if (iter->m_xmOOBB.Intersects(m_pObjects[i].m_xmOOBB)) {
				iter->m_pCollider = &m_pObjects[i];
				m_pObjects[i].m_pCollider = &(*iter);
			}
		}
	}

	// ť�� - �Ѿ� �浹 ó��
	for (int i = 0; i < m_nObjects; ++i) {
		for (auto iter = m_vBullets.begin(); iter != m_vBullets.end();) {
			if (m_pObjects[i].m_pCollider && &(*iter).m_pCollider->m_pCollider) {
				Particle_on = true;

				iter->SetMesh(NULL);
				m_vBullets.erase(iter++);

				// ��ƼŬ ����
				for (int m_nParticle = 0; m_nParticle < 50; ++m_nParticle) {
					float dir_x = xdir_ul(dre);
					float dir_y = ydir_ul(dre);
					float dir_z = zdir_ul(dre);

					m_pParticle[m_nParticle].SetColor(m_pObjects[i].GetColor());
					m_pParticle[m_nParticle].SetPosition(m_pObjects[i].GetPosition());
					m_pParticle[m_nParticle].SetMovingDirection(XMFLOAT3(dir_x, dir_y, dir_z));
				}

				// ť�� �����
				m_pObjects[i].SetCubeType(m_pPlayer, m_pObjects, i);
				
				// �浹ü �ʱ�ȭ
				m_pObjects[i].m_pCollider = NULL;
				break;
			}
			else
				++iter;
		}
	}

	/*
	// �浹�Ǵ� Ÿ�� ���� ������ �ٸ�
	// ���࿡ ��� �浹�� �ȴٸ�
	// �浹 �� ���⿡ ���� �� ������ �ٲ���� ��
	// ť�곢���� �浹�� ���� �ʴ� ������ ....

	// Ÿ���� ������ �浹�� �Ѵ��� ����� ����.
	// Ÿ�� ���� �������� �ʾƼ� �н�

	// ť�곢�� �浹 Ȯ��
	for (int i = 0; i < m_nObjects; i++)
	{
		for (int j = (i + 1); j < m_nObjects; j++)
		{
			//m_pObjects[i].type == m_pObjects[j].type
			if (m_pObjects[i].m_xmOOBB.Intersects(m_pObjects[j].m_xmOOBB))
			{
				// j�� �浹ü�� i 
				// i�� �浹ü�� j ����
				m_pObjects[i].m_pCollider = &m_pObjects[j];
				m_pObjects[j].m_pCollider = &m_pObjects[i];
			}
		}
	}
	// �浹 ó��
	for (int i = 0; i < m_nObjects; i++)
	{
		// i �浹ü�� 
		if (m_pObjects[i].m_pCollider && m_pObjects[i].m_pCollider->m_pCollider)
		{
			// Temp ó�� �� �����ϰ�
			XMFLOAT3 xmf3MovingDirection = m_pObjects[i].m_xmf3MovingDirection;
			float fMovingSpeed = m_pObjects[i].m_fMovingSpeed;
			// ���� �ٲٰ�
			m_pObjects[i].m_xmf3MovingDirection = m_pObjects[i].m_pCollider->m_xmf3MovingDirection;
			m_pObjects[i].m_fMovingSpeed = m_pObjects[i].m_pCollider->m_fMovingSpeed;
			// ��������� �ٲٰ�
			m_pObjects[i].m_pCollider->m_xmf3MovingDirection = xmf3MovingDirection;
			m_pObjects[i].m_pCollider->m_fMovingSpeed = fMovingSpeed;
			// �浹ü NULL
			m_pObjects[i].m_pCollider->m_pCollider = NULL;
			m_pObjects[i].m_pCollider = NULL;
		}
	}
	*/

	// ���� ��ũ��
	XMFLOAT3 m_nPlayer = m_pPlayer->GetPosition();
	for (int m_nWall_cnt = 0; m_nWall_cnt < 12; ++m_nWall_cnt) {
		XMFLOAT3 m_nWall = m_pWall[m_nWall_cnt].GetPosition();
		if (m_nPlayer.z >(m_nWall.z + 15.0f)) {
			m_pWall[m_nWall_cnt].SetPosition(0.0f, 0.0f, 220.0f + (cnt * 20.0f));
			m_pWall[m_nWall_cnt].SetOOBB(XMFLOAT3(0.0f, 0.0f, 220.0f + (cnt * 20.0f)),
				XMFLOAT3(15.0f, 15.0f, 10.0f),
				XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
			++cnt;
		}
	}
	
	// ť�� �����
	for (int m_nCube_cnt = 0; m_nCube_cnt < m_nObjects; ++m_nCube_cnt) {
		XMFLOAT3 m_nCube = m_pObjects[m_nCube_cnt].GetPosition();
		if (m_nPlayer.z > (m_nCube.z + 5.0f)) {
			m_pObjects[m_nCube_cnt].SetCubeType(m_pPlayer, m_pObjects, m_nCube_cnt);
		}
	}

	// �Ѿ��� �ִϸ��̼�
	for (auto iter = m_vBullets.begin(); iter != m_vBullets.end();) {
		iter->Animate();

		if (iter->GetPosition().z > m_pPlayer->GetPosition().z + 10.0f) {
			m_BulletTimer = true;
		}
		else
			m_BulletTimer = false;

		// �÷��̾�� 100 ���� �־����� ������
		if (iter->GetPosition().z >= m_pPlayer->GetPosition().z + 100.0f) {
			iter->SetMesh(NULL);
			m_vBullets.erase(iter++);
		}
		else
			++iter;
	}

	// ��ƼŬ �ִϸ��̼�
	for (int m_nCube = 0; m_nCube < m_nObjects; ++m_nCube) {
		for (int i = 0; i < 50; ++i) {
			m_pParticle[i].Animate();
		}
	}
}
//��� ������
void CGameFramework::FrameAdvance()
{
	if (!m_bActive) return;

	ProcessInput();

	AnimateObjects();

	ClearFrameBuffer(RGB(255, 255, 255));

	for (int wall_cnt = 0; wall_cnt < 12; ++wall_cnt)
		m_pWall[wall_cnt].Render(m_hDCFrameBuffer, m_pPlayer->m_pCamera);

	for (int i = 0; i < m_nObjects; i++) m_pObjects[i].Render(m_hDCFrameBuffer, m_pPlayer->m_pCamera);

	m_pPlayer->Render(m_hDCFrameBuffer, m_pPlayer->m_pCamera);

	// �Ѿ� �߰�
	for (auto iter = m_vBullets.begin(); iter != m_vBullets.end(); ++iter)
		iter->Render(m_hDCFrameBuffer, m_pPlayer->m_pCamera);

	// ��ƼŬ �߰�
	if (Particle_on == true) {
		for (int i = 0; i < 50; ++i)
			m_pParticle[i].Render(m_hDCFrameBuffer, m_pPlayer->m_pCamera);
	}

	PresentFrameBuffer();
}


